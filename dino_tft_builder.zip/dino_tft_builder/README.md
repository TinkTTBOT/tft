Dino TFT Builder
================

Project skeleton for a Flutter app that fetches TFT data at runtime from CommunityDragon:
https://raw.communitydragon.org/latest/cdragon/tft/en_us.json

How to build APK (locally):
1. Install Flutter SDK (https://flutter.dev)
2. Unzip this project and run:
   flutter pub get
   flutter build apk --release
3. APK will be in build/app/outputs/flutter-apk/app-release.apk

Notes:
- The app downloads the full TFT dataset on first run; ensure device has internet.
- Language: Vietnamese. UI supports search, filter by cost and trait, save/load teams.

Sources:
- CommunityDragon TFT data: https://raw.communitydragon.org/latest/cdragon/tft/en_us.json
- CommunityDragon raw index: https://raw.communitydragon.org/latest/

