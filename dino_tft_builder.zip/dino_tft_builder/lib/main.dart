\
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  runApp(DinoTFTApp());
}

class DinoTFTApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Dino TFT Builder',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: HomePage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class Champion {
  final String id;
  final String name;
  final int cost;
  final List<String> traits;
  final List<String> suggestedItems;
  Champion({required this.id, required this.name, required this.cost, required this.traits, required this.suggestedItems});
  factory Champion.fromCommunityDragon(Map<String,dynamic> j) {
    // CommunityDragon structure: pieces inside `units` or similar—this method tries to be robust.
    final name = (j['name'] ?? j['displayName'] ?? j['localizedName'] ?? '').toString();
    final cost = (j['cost'] is int) ? j['cost'] : (j['tier'] is int ? j['tier'] : 1);
    List<String> traits = [];
    if (j['traits'] != null && j['traits'] is List) {
      traits = (j['traits'] as List).map((e)=>e.toString()).toList();
    } else if (j['characteristics'] != null && j['characteristics'] is List) {
      traits = (j['characteristics'] as List).map((e)=>e.toString()).toList();
    }
    // suggestedItems not provided by dataset; leave empty.
    return Champion(id: j['id']?.toString() ?? name, name: name, cost: cost, traits: traits, suggestedItems: []);
  }
  Map<String,dynamic> toJson() => {'id':id,'name':name,'cost':cost,'traits':traits,'suggestedItems':suggestedItems};
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

enum LoadState { idle, loading, done, error }

class _HomePageState extends State<HomePage> {
  List<Champion> bench = [];
  List<Champion> team = [];
  List<Map<String,dynamic>> savedTeams = [];
  LoadState loadState = LoadState.idle;
  String errorMsg = '';
  String filterTrait = '';
  int? filterCost;

  @override
  void initState() {
    super.initState();
    _loadSavedTeams();
    _fetchData();
  }

  Future<void> _fetchData() async {
    setState(() { loadState = LoadState.loading; });
    try {
      final url = 'https://raw.communitydragon.org/latest/cdragon/tft/en_us.json';
      final resp = await http.get(Uri.parse(url));
      if (resp.statusCode != 200) throw Exception('Không tải được dữ liệu (status ${resp.statusCode})');
      final Map<String,dynamic> data = jsonDecode(resp.body);
      // communitydragon en_us.json often has 'units' or 'units' nested; try to find champions list:
      List<dynamic> units = [];
      if (data.containsKey('units')) units = data['units'];
      else if (data.containsKey('champions')) units = data['champions'];
      else if (data.containsKey('units_data')) units = data['units_data'];
      else {
        // Fallback: try to collect objects that look like units
        units = [];
        data.forEach((k,v){
          if (v is List) {
            // heuristic: list items that contain 'name' and 'cost'
            if (v.isNotEmpty && v[0] is Map && v[0].containsKey('name') && (v[0].containsKey('cost') || v[0].containsKey('tier'))) {
              units = v;
            }
          }
        });
      }
      final champs = units.map((u)=>Champion.fromCommunityDragon(u as Map<String,dynamic>)).toList();
      setState(() {
        bench = champs;
        loadState = LoadState.done;
      });
    } catch (e) {
      setState(() {
        loadState = LoadState.error;
        errorMsg = e.toString();
      });
    }
  }

  Future<void> _loadSavedTeams() async {
    final sp = await SharedPreferences.getInstance();
    final raw = sp.getStringList('savedTeams') ?? [];
    setState(() {
      savedTeams = raw.map((s)=>jsonDecode(s) as Map<String,dynamic>).toList();
    });
  }

  Future<void> _saveCurrentTeamAs(String name) async {
    final sp = await SharedPreferences.getInstance();
    final data = {'name':name,'createdAt':DateTime.now().toIso8601String(),'team':team.map((c)=>c.toJson()).toList()};
    final list = sp.getStringList('savedTeams') ?? [];
    list.add(jsonEncode(data));
    await sp.setStringList('savedTeams', list);
    await _loadSavedTeams();
  }

  Map<String,int> _traitCounts() {
    final Map<String,int> counts = {};
    for (var c in team) {
      for (var t in c.traits) {
        counts[t] = (counts[t] ?? 0) + 1;
      }
    }
    return counts;
  }

  List<String> _aggregateSuggestedItems() {
    final Map<String,int> freq = {};
    for (var c in team) {
      for (var it in c.suggestedItems) {
        freq[it] = (freq[it] ?? 0) + 1;
      }
    }
    final items = freq.keys.toList();
    items.sort((a,b) => freq[b]!.compareTo(freq[a]!));
    return items;
  }

  void _addToTeam(Champion c) {
    if (team.length >= 9) return;
    setState(()=>team.add(c));
  }
  void _removeFromTeam(int idx) => setState(()=>team.removeAt(idx));
  void _loadSaved(Map<String,dynamic> s) {
    setState(()=> team = (s['team'] as List).map((e)=>Champion(id:e['id'], name:e['name'], cost:e['cost'], traits: List<String>.from(e['traits']), suggestedItems: List<String>.from(e['suggestedItems'] ?? []))).toList());
  }

  List<Champion> _visibleBench() {
    return bench.where((c){
      if (filterCost != null && c.cost != filterCost) return false;
      if (filterTrait.isNotEmpty && !c.traits.any((t)=>t.toLowerCase().contains(filterTrait.toLowerCase()))) return false;
      return true;
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    final traitCounts = _traitCounts();
    final suggestedItems = _aggregateSuggestedItems();

    return Scaffold(
      appBar: AppBar(
        title: Text('Dino TFT Builder'),
        actions: [
          IconButton(icon: Icon(Icons.save), onPressed: () async {
            if (team.isEmpty) return;
            final ctrl = TextEditingController();
            final ok = await showDialog<bool>(
              context: context,
              builder: (_) => AlertDialog(
                title: Text('Lưu đội'),
                content: TextField(controller: ctrl, decoration: InputDecoration(hintText:'Tên đội')),
                actions: [
                  TextButton(onPressed: ()=>Navigator.pop(context,false), child: Text('Hủy')),
                  TextButton(onPressed: ()=>Navigator.pop(context,true), child: Text('Lưu')),
                ],
              )
            );
            if (ok==true) await _saveCurrentTeamAs(ctrl.text.isEmpty ? 'Đội ${DateTime.now().toIso8601String()}' : ctrl.text);
          })
        ],
      ),
      body: loadState==LoadState.loading ? Center(child: Column(mainAxisSize: MainAxisSize.min, children:[CircularProgressIndicator(), SizedBox(height:8), Text('Đang tải dữ liệu TFT...')])) :
            loadState==LoadState.error ? Center(child: Text('Lỗi tải dữ liệu:\\n$errorMsg')) :
      Row(
        children: [
          Expanded(
            flex:5,
            child: Column(
              children: [
                Padding(padding: EdgeInsets.all(8), child: Text('Danh sách tướng (${bench.length})', style: TextStyle(fontWeight: FontWeight.bold))),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal:8),
                  child: Row(children:[
                    Expanded(child: TextField(decoration: InputDecoration(hintText:'Tìm tướng hoặc tộc...'), onChanged: (v){ setState(()=>filterTrait=v); })),
                    SizedBox(width:8),
                    DropdownButton<int?>(
                      value: filterCost,
                      hint: Text('Cost'),
                      items: [null,1,2,3,4,5,6,7].map((c)=>DropdownMenuItem(value:c, child: Text(c==null?'Tất cả':c.toString()))).toList(),
                      onChanged: (v)=>setState(()=>filterCost=v),
                    ),
                    SizedBox(width:8),
                    IconButton(icon: Icon(Icons.refresh), onPressed: _fetchData),
                  ])
                ),
                Expanded(
                  child: ListView.builder(
                    itemCount: _visibleBench().length,
                    itemBuilder: (_,i){
                      final c = _visibleBench()[i];
                      return ListTile(
                        title: Text('${c.name} (cost ${c.cost})'),
                        subtitle: Text(c.traits.join(' • ')),
                        trailing: IconButton(icon: Icon(Icons.add), onPressed: ()=>_addToTeam(c)),
                      );
                    }
                  ),
                )
              ],
            ),
          ),
          VerticalDivider(width:1),
          Expanded(
            flex:6,
            child: Column(
              children: [
                Padding(padding: EdgeInsets.all(8), child: Text('Đội hiện tại (${team.length})', style: TextStyle(fontWeight: FontWeight.bold))),
                Expanded(
                  child: ListView.builder(
                    itemCount: team.length,
                    itemBuilder: (_,i){
                      final c = team[i];
                      return ListTile(
                        title: Text(c.name),
                        subtitle: Text(c.traits.join(' • ')),
                        trailing: IconButton(icon: Icon(Icons.delete), onPressed: ()=>_removeFromTeam(i)),
                      );
                    }
                  ),
                ),
                Divider(),
                Padding(
                  padding: EdgeInsets.all(8),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children:[
                    Text('Tộc/Hệ:', style: TextStyle(fontWeight: FontWeight.bold)),
                    SizedBox(height:6),
                    Wrap(spacing:8, runSpacing:6, children: traitCounts.entries.map((e)=>Chip(label: Text('${e.key}: ${e.value}'))).toList()),
                    SizedBox(height:12),
                    Text('Gợi ý trang bị:', style: TextStyle(fontWeight: FontWeight.bold)),
                    SizedBox(height:6),
                    Wrap(spacing:8, children: suggestedItems.map((s)=>Chip(label: Text(s))).toList()),
                  ])
                )
              ],
            ),
          ),
          VerticalDivider(width:1),
          Expanded(
            flex:4,
            child: Column(children:[
              Padding(padding: EdgeInsets.all(8), child: Text('Đã lưu', style: TextStyle(fontWeight: FontWeight.bold))),
              Expanded(child: ListView.builder(
                itemCount: savedTeams.length,
                itemBuilder: (_,i){
                  final s = savedTeams[i];
                  return ListTile(
                    title: Text(s['name'] ?? 'Untitled'),
                    subtitle: Text('Saved: ${s['createdAt']?.toString()?.split('T')?.first ?? ''}'),
                    onTap: ()=>_loadSaved(s),
                  );
                }
              )),
              if (savedTeams.isNotEmpty) TextButton.icon(
                icon: Icon(Icons.delete_forever),
                label: Text('Xóa tất cả'),
                onPressed: () async {
                  final sp = await SharedPreferences.getInstance();
                  await sp.remove('savedTeams');
                  await _loadSavedTeams();
                },
              )
            ]),
          )
        ],
      ),
    );
  }
}
